require 'test_helper'

class SplashHelperTest < ActionView::TestCase
end
