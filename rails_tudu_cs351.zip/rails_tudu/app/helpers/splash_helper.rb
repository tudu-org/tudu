module SplashHelper
end
