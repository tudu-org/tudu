$(document).ready(function() {
  $("td").css('background-color', #99D6EB);
});