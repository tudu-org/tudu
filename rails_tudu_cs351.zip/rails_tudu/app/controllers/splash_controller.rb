class SplashController < ApplicationController
  def index
  end
end
