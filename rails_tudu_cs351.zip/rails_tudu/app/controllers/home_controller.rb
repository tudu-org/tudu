class HomeController < ApplicationController

end